package com.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.conn.DBConn;
import com.dao.StudentDAO;
import com.entity.Student;

@WebServlet("/Update")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String name=request.getParameter("name");
		String dob=request.getParameter("dob");
		String address=request.getParameter("address");
		String qualification=request.getParameter("qualification");
		String email=request.getParameter("email");
		int id=Integer.parseInt(request.getParameter("id"));
		Student st=new Student(id,name,dob,address,qualification,email);
	    StudentDAO dao=new StudentDAO(DBConn.getconn());
	    HttpSession session=request.getSession();
	    
	    boolean f=dao.updateStudent(st);
	    
	
	    if(f) {
	    	 session.setAttribute("succMsg","Student details update successfully.");
	    	 response.sendRedirect("index.jsp");
	    }
	    else {
	    	 session.setAttribute("errorMsg","Something went wrong");
	    	 response.sendRedirect("index.jsp");
	    }
	
	    
	   
	}

}
