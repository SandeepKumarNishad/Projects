package com.servlet;
import com.conn.DBConn;
import com.dao.StudentDAO;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.entity.Student;
import com.mysql.cj.Session;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("name");
		String dob=request.getParameter("dob");
		String address=request.getParameter("address");
		String qualification=request.getParameter("qualification");
		String email=request.getParameter("email");
		
		Student st=new Student(name,dob,address,qualification,email);
	    StudentDAO dao=new StudentDAO(DBConn.getconn());
	    boolean b=dao.addStudent(st);
	    HttpSession session=request.getSession();
	    if(b) {
	    	 session.setAttribute("succMsg","Student details submit successfully.");
	    	 response.sendRedirect("add_student.jsp");
	    }
	    else {
	    	 session.setAttribute("errorMsg","Something went wrong");
	    	 response.sendRedirect("add_student.jsp");
	    }
	
	}

}
