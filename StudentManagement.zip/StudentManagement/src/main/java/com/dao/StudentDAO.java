package com.dao;
import java.util.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.conn.DBConn;
import com.entity.Student;

public class StudentDAO {
	private Connection conn;

public StudentDAO() {
	super();
}

public StudentDAO(Connection conn) {
	super();
	this.conn = conn;
}



public boolean addStudent(Student st) {
	boolean f=false;
	
	try {
		String sql="insert into student(fullname,dob,address,qualification,email) values(?,?,?,?,?)";
		PreparedStatement ps=conn.prepareStatement(sql);
		ps.setString(1,st.getFullname());
		ps.setString(2,st.getDob());
		ps.setString(3,st.getAddress());
		ps.setString(4,st.getQualification());
		ps.setString(5,st.getEmail());
		
		int i=ps.executeUpdate();
		if(i==1) {
			f=true;
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	return f;
	
}

public List<Student> getAllStudent(){
	List<Student> list=new ArrayList<Student>();
	Student s=null;
	try {
		String sql1="select * from Student";
		PreparedStatement ps=conn.prepareStatement(sql1);
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			s=new Student();
			s.setId(rs.getInt(1));
			s.setFullname(rs.getString(2));
			s.setDob(rs.getString(3));
			s.setAddress(rs.getString(4));
			s.setQualification(rs.getString(5));
			s.setEmail(rs.getString(6));
			list.add(s);
		}
	} catch (Exception e) {
		e.printStackTrace();
		
	}
	return list;
}

public Student getStudentById(int id) {

	Student s=null;
	try {
		String sql="select * from Student where id=?";
		PreparedStatement ps=conn.prepareStatement(sql);
		ps.setInt(1,id);
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			s=new Student();
			s.setId(rs.getInt(1));
			s.setFullname(rs.getString(2));
			s.setDob(rs.getString(3));
			s.setAddress(rs.getString(4));
			s.setQualification(rs.getString(5));
			s.setEmail(rs.getString(6));
		}
	} catch (Exception e) {
		e.printStackTrace();
		
	}
	return s;
}
public boolean updateStudent(Student st) {
boolean f=false;

try {
	String sql="update student set fullname=?,dob=?,address=?,qualification=?,email=? where id=? ";
	PreparedStatement ps=conn.prepareStatement(sql);
	ps.setString(1,st.getFullname());
	ps.setString(2,st.getDob());
	ps.setString(3,st.getAddress());
	ps.setString(4,st.getQualification());
	ps.setString(5,st.getEmail());
	ps.setInt(6,st.getId());
	
	int i=ps.executeUpdate();
	if(i==1) {
		f=true;
	}
} catch (Exception e) {
	e.printStackTrace();
}
return f;
}

public boolean deleteStudent(int id) {
	boolean f=false;
	
	try {
		 String sql="delete from student where id=?";
		 PreparedStatement ps=conn.prepareStatement(sql);
		 ps.setInt(1,id);
		 int i=ps.executeUpdate();
		 
		 if(i==1) {
			 f=true;
			}
		
	} catch (Exception e) {
	
		e.printStackTrace();
	}
	
	return f;
}

}
